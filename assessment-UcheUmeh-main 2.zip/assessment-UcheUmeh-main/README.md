# 4100-Assessment

This 2.5-hour exam is in 2 parts.
Part 1 is a series of short questions and tasks (25 points)

Part 2 is a longer practical task. You should spend the bulk of your time here. (75 points)

You may whatever online resources are appropriate; however, any excessive copy-pasting will be severely penalised and may result in failure.

Please ask if you have any questions.

