For this part of the exam, please open up index.html in the browser.

1. On opening the page, it seems no CSS has been applied. Please correct. (5 points)
2. Line 10 should not be a <p> as it's the main heading of the page. Please fix (2 points)
3. I've been told the page isn't semantic. Please explain why that is below, and take steps to correct. (3 points)

Answer: Because some of tags are not specific to their purpose, for example the <Title> tags was in <p> in line 10.


4. Implement the feature requested on line 14 (2 points)
5. On line 18, please create a form. It should have:
    - An input field for a name
    - An input field for an email address (the field should be able to check it's actually an email)
    - Both of these fields should be required. 
    - A submit button that says "Add to Newsletter".
( 6 points)

6. On a mobile view, the form should sit at the below the area containing "Sub section heading"; when the screen size is greater that 550px, it should move to the left of this area. (7 points)